"""
Evaluation metrics for the DP-FL-IDS (RO3).

Reports the detection-quality metrics used throughout the results chapter:
accuracy, macro-averaged F1, and the **false-positive rate** (benign flows
predicted as an attack — the operational false-alarm rate). Convergence speed,
cumulative privacy budget, and per-round overhead are time-series metrics
tracked by the FL engine, not here. Also provides the confusion matrix and a
per-category (8-family) breakdown for the analysis chapter.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)

from ..data import loaders
from ..data.config import label_to_category


@torch.no_grad()
def predict(model: nn.Module, loader, device) -> tuple[np.ndarray, np.ndarray]:
    model.to(device).eval()
    ys, ps = [], []
    for xb, yb in loader:
        logits = model(xb.to(device))
        ps.append(logits.argmax(1).cpu().numpy())
        ys.append(yb.numpy())
    return np.concatenate(ys), np.concatenate(ps)


def _benign_id() -> int | None:
    return loaders.load_label_map().get("BenignTraffic")


def false_positive_rate(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Benign samples wrongly flagged as an attack / all benign samples."""
    bid = _benign_id()
    if bid is None:
        return float("nan")
    benign = y_true == bid
    n = int(benign.sum())
    if n == 0:
        return float("nan")
    false_alarms = int(((y_pred != bid) & benign).sum())
    return false_alarms / n


def core_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "macro_precision": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "fpr": false_positive_rate(y_true, y_pred),
    }


def evaluate_full(model: nn.Module, loader, device) -> dict:
    y_true, y_pred = predict(model, loader, device)
    m = core_metrics(y_true, y_pred)
    m["per_category"] = per_category_metrics(y_true, y_pred)
    return m


def _category_lut() -> tuple[np.ndarray, list[str]]:
    """``(label_id -> category_index)`` lookup table, plus the category names.

    Built once per process. The previous implementation resolved the category of
    *every test row* with a dict lookup plus a chain of string comparisons, twice
    — on a 9M-row held-out set that is ~18M Python-level string classifications
    per evaluation. There are only 34 labels, so a 34-element table indexed by
    label id gives the same answer as one vectorised gather.
    """
    global _LUT_CACHE
    if _LUT_CACHE is None:
        id2label = loaders.id_to_label()
        n = (max(id2label) + 1) if id2label else 0
        cats: list[str] = []
        lut = np.zeros(n, dtype=np.int16)
        for i in range(n):
            cat = label_to_category(id2label[i]) if i in id2label else "Unknown"
            if cat not in cats:
                cats.append(cat)
            lut[i] = cats.index(cat)
        _LUT_CACHE = (lut, cats)
    return _LUT_CACHE


_LUT_CACHE: tuple[np.ndarray, list[str]] | None = None


def per_category_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Recall + support within each of the 8 attack families."""
    lut, cats = _category_lut()
    ct = lut[np.clip(y_true, 0, len(lut) - 1)]
    cp = lut[np.clip(y_pred, 0, len(lut) - 1)]
    support = np.bincount(ct, minlength=len(cats))
    hits = np.bincount(ct[ct == cp], minlength=len(cats))
    return {cats[i]: {"support": int(support[i]),
                      "recall": float(hits[i] / support[i]) if support[i] else 0.0}
            for i in np.argsort(cats).tolist() if support[i]}


def confusion(y_true: np.ndarray, y_pred: np.ndarray, n_classes: int) -> np.ndarray:
    return confusion_matrix(y_true, y_pred, labels=list(range(n_classes)))
