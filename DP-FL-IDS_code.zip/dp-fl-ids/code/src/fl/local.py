"""
One gNB's local update for a single FL round — the shared "fit" logic used by
both the sequential engine and the Flower ClientApp.

Pipeline: load global weights → (if Byzantine data-poisoning) flip labels →
train locally (optionally with Opacus DP-SGD at the round's noise multiplier σ)
→ (if Byzantine update-poisoning) transform the update → return new parameters.
"""

from __future__ import annotations

import numpy as np
import torch

from ..attacks import byzantine
from ..models.lstm_ids import build_model
from ..privacy.dp_engine import attach_dp, sample_rate as _sample_rate
from ..training import train_epochs
from .params import Params, get_params, set_params


def local_train(*, global_params: Params, x: np.ndarray, y: np.ndarray,
                n_features: int, n_classes: int, model_name: str, hidden: int,
                epochs: int, batch_size: int, lr: float, device: torch.device,
                is_byzantine: bool = False, attack: str = "none",
                attack_scale: float = 10.0, attack_noise_std: float = 1.0,
                dp: bool = False, noise_multiplier: float = 1.0,
                max_grad_norm: float = 1.0, seed: int = 0,
                optimizer_name: str = "adam", momentum: float = 0.9
                ) -> tuple[Params, int, dict]:
    """Return ``(new_params, num_examples, info)`` for one client-round."""
    torch.manual_seed(seed)
    model = build_model(model_name, n_features, n_classes, hidden=hidden)
    set_params(model, global_params)
    model.to(device)

    # Data poisoning (label flip) happens before training.
    y_train = byzantine.maybe_flip_labels(
        y, n_classes, active=(is_byzantine and attack == "label_flip"), seed=seed)

    # copy=False: the loaders already hand us float32/int64, so the casts are
    # no-ops on dtype but were allocating a full duplicate of the shard on every
    # client-round — ~780 MB per call once shards reach full-corpus size.
    ds = torch.utils.data.TensorDataset(
        torch.from_numpy(np.asarray(x, dtype=np.float32)),
        torch.from_numpy(np.asarray(y_train, dtype=np.int64)))
    loader = torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=True)

    info: dict = {"dp": bool(dp), "num_examples": int(len(y))}
    # SGD is the canonical DP-SGD optimizer; Adam's per-coordinate normalisation
    # fights the clip+noise and badly hurts DP utility (see RO2/RO3 analysis).
    if optimizer_name.lower() == "sgd":
        optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    if dp and noise_multiplier and noise_multiplier > 0:
        engine, model, optimizer, loader = attach_dp(
            model, optimizer, loader, noise_multiplier=noise_multiplier,
            max_grad_norm=max_grad_norm)
        train_epochs(model, loader, epochs=epochs, device=device, optimizer=optimizer)
        q = _sample_rate(batch_size, len(y))
        steps = epochs * int(np.ceil(len(y) / batch_size))
        info.update(noise_multiplier=float(noise_multiplier), sample_rate=float(q),
                    steps=int(steps))
    else:
        train_epochs(model, loader, epochs=epochs, device=device, optimizer=optimizer)
        info.update(noise_multiplier=0.0, sample_rate=0.0, steps=0)

    new_params = get_params(model)

    # Update poisoning (applied to the honest delta).
    if is_byzantine and attack in byzantine.UPDATE_ATTACKS:
        new_params = byzantine.apply_update_attack(
            attack, global_params, new_params,
            scale=attack_scale, noise_std=attack_noise_std, seed=seed)
        info["poisoned"] = True

    return new_params, int(len(y)), info
