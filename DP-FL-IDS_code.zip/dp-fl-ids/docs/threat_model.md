# Threat Model — DP-FL-IDS for 6G Radio Access Networks

**Deliverable of RO1** (integrated framework + threat model).
Companion to the implementation in `src/` and the experiment campaign in
`run_experiment.py`. Every adversary capability described here maps to a concrete
mechanism in the code, and every defence maps to a Research Objective.

---

## 1. System under protection

A 6G Open RAN (O-RAN) slice modelled as **10 gNBs** (`NUM_CLIENTS = 10`) that
cooperatively train an intrusion-detection model (IDS) without sharing raw
traffic. The learning is **federated**: each gNB trains locally on its own flows
and telemetry, and a central aggregator — logically the **Near-RT RIC** (RAN
Intelligent Controller) — combines the model updates each round.

- **Data at each gNB.** CICIoT2023 network-flow features (46) augmented with 7
  synthetic RAN-telemetry features (RSRP, SINR, RSRQ, PRB utilisation, handover
  rate, beam-failure count, throughput) → a **53-dimensional** feature vector,
  classified into **34** fine-grained labels / **8** coarse categories.
- **Non-IID reality.** Traffic composition differs per gNB (Dirichlet α = 0.3
  partition, `DIRICHLET_ALPHA`); no gNB sees the full attack distribution. This
  heterogeneity is itself a defensive challenge — it widens the natural spread of
  *honest* updates, which a robust aggregator must not mistake for attacks.
- **What is exchanged.** Only model parameters (an ordered `list[np.ndarray]`,
  see `src/fl/params.py`), never raw flows. Raw data never leaves a gNB.

### Assets to protect
1. **Confidentiality of subscriber/network data** — an update must not leak the
   raw traffic it was trained on (membership / reconstruction risk).
2. **Integrity of the global IDS model** — a poisoned model that misclassifies
   attacks (or floods false alarms) degrades the security of every gNB.
3. **Availability / convergence** — the federation must still converge to a
   useful detector under noise and adversarial pressure.

---

## 2. Adversaries and capabilities

We consider two orthogonal adversary classes, and their interaction (RO4).

### 2.1 Honest-but-curious observer (privacy adversary)
- **Goal:** infer properties of a gNB's private training data from the model
  updates it broadcasts (membership inference, attribute/reconstruction attacks).
- **Position:** the aggregator, a passive network eavesdropper on the RIC link,
  or any party that observes per-client updates or the global model.
- **Capability:** read access to updates/global model across rounds; *no* ability
  to modify them.
- **Out of scope of this control:** breaking the transport encryption itself —
  we assume the RIC link is encrypted; the residual leakage we defend against is
  the *statistical* leakage inherent in the updates.

**Defence → RO1/RO2/RO3 (Differential Privacy).** Each gNB trains with
**DP-SGD**: per-sample gradient clipping to `max_grad_norm = C` and Gaussian
noise `σ·C` (`src/privacy/dp_engine.py`, Opacus `PrivacyEngine`). This gives a
formal **(ε, δ)-DP** guarantee (RDP accountant, δ = 1e-5) bounding what any
observer can learn about a single record — see `epsilon_from_schedule`. RO2's
adaptive-ε scheduler (`src/privacy/adaptive_eps.py`) allocates the *same* total
budget non-uniformly across rounds to improve utility at fixed privacy; RO3
characterises the resulting privacy–utility trade-off across ε ∈ {1, 5, 10, 50}.

### 2.2 Byzantine (malicious) gNB (integrity/availability adversary)
- **Goal:** corrupt the global model — either targeted (evade detection of a
  chosen attack) or untargeted (destroy overall accuracy / cause false-alarm
  storms).
- **Position:** one or more compromised gNBs participating in training. We model
  a fraction **f ≤ 30%** of the 10 clients as malicious (`byzantine_fraction`,
  selected deterministically by `select_byzantine`). Multi-Krum requires
  `n − f − 2 ≥ 1`, i.e. f ≤ 7 for n = 10, so f ≤ 30% is well within the
  breakdown point.
- **Capability (white-box, colluding):** a Byzantine gNB fully controls its own
  local data, training process, and the update it submits. It knows the model
  architecture and the current global parameters. Colluding attackers may
  coordinate identical malicious updates.
- **Assumed limits:** the aggregator (RIC) itself is **trusted and correct**;
  attackers cannot forge *other* gNBs' identities (no Sybil beyond the modelled
  fraction), cannot break authentication of the RIC channel, and are a minority.

**Attack primitives implemented** (`src/attacks/byzantine.py`):

| Family | Attack | Mechanism in code | Intent |
|--------|--------|-------------------|--------|
| Data poisoning | `label_flip` | corrupt local labels before training | targeted mislabelling |
| Model poisoning | `sign_flip` | submit `−scale·Δ` (reverse the honest update) | untargeted divergence |
| Model poisoning | `scale`/`boost` | submit `scale·Δ` (model-replacement/boosting) | dominate the average |
| Model poisoning | `gaussian` | add Gaussian noise to the update | degrade convergence |
| Model poisoning | `random` | ignore training, send random params | denial of convergence |

**Defence → RO1/RO4 (Byzantine-robust aggregation).** The RIC replaces FedAvg
with **Multi-Krum** (`src/fl/aggregation.py`): it scores each update by the sum
of squared distances to its `n − f − 2` nearest neighbours and averages only the
`n − f` most central updates, excluding outliers. **Trimmed-Mean** is provided as
a comparison defence, and **FedAvg** as the undefended baseline that quantifies
attack impact.

### 2.3 Combined adversary (RO4 — the central interaction question)
The two defences can conflict: **DP Gaussian noise perturbs every update**, which
may blur the distance geometry Multi-Krum relies on to spot Byzantine outliers.
The threat we specifically study is *"privacy noise masking attacks"* — whether
adding DP makes the federation **less** Byzantine-robust. This is measured by
`src/analysis/interaction.py` (Byzantine exclusion rate with vs without DP, and
Krum score-separation as DP-scale noise σ grows).

---

## 3. Trust assumptions (explicit)

| Entity | Trust | Rationale |
|--------|-------|-----------|
| Near-RT RIC / aggregator | **Trusted, honest** | Standard FL assumption; the aggregator runs the robust rule correctly. (A malicious aggregator is out of scope — would need secure aggregation / TEEs, noted as future work.) |
| Honest gNBs | Trusted but **privacy-conscious** | They follow the protocol but must not have their data leaked → DP protects them from the aggregator/observers. |
| Byzantine gNBs (≤ 30%) | **Untrusted** | Fully adversarial, colluding, white-box. |
| RIC transport channel | Encrypted & authenticated | We defend the *residual* statistical leakage, not the wire. |
| Client identity / count | Fixed, no Sybil beyond f | Enrolment is controlled by the operator. |

---

## 4. Attacker knowledge and threat surface summary

- **Knowledge:** white-box (architecture + current global model known to all).
- **Corruption model:** static — the set of Byzantine gNBs is fixed per run
  (deterministic selection), matching a "compromised base stations" scenario.
- **Collusion:** allowed among Byzantine gNBs.
- **Attack timing:** every round (persistent), the strongest case for the
  defence.

```
        privacy adversary (read)                 Byzantine gNBs (write)
                  │                                        │
     observes updates / global model        submit poisoned updates (≤30%)
                  │                                        │
                  ▼                                        ▼
        ┌───────────────────────────── Near-RT RIC (trusted) ─────────────────┐
        │  Multi-Krum robust aggregation  ──►  excludes Byzantine outliers     │  RO1/RO4
        └──────────────────────────────────────────────────────────────────────┘
                  ▲
     each gNB trains locally with DP-SGD (clip C + Gaussian σ) ──► (ε,δ)-DP     RO1/RO2/RO3
```

---

## 5. Threats → controls → objectives (traceability)

| Threat | Control | Where | RO | Evidence |
|--------|---------|-------|----|----------|
| Data leakage from updates | (ε,δ)-DP via DP-SGD | `privacy/dp_engine.py` | RO1 | ε lands on target budget |
| Wasted privacy budget (uniform σ) | Adaptive-ε schedule at fixed total ε | `privacy/adaptive_eps.py` | RO2 | schedules hit same ε, differ in utility |
| Unknown privacy cost of noise | Privacy–utility characterisation | `run_experiment.py: privacy_utility` | RO3 | accuracy/F1/FPR vs ε ∈ {1,5,10,50} |
| Model poisoning by Byzantine gNBs | Multi-Krum (+ Trimmed-Mean) | `fl/aggregation.py` | RO1/RO4 | FedAvg collapses; Multi-Krum excludes attackers |
| DP noise masking attacks | DP × Multi-Krum interaction study | `analysis/interaction.py` | RO4 | exclusion rate & score-separation vs σ |

---

## 6. Explicitly out of scope

- **Malicious aggregator / RIC compromise** (needs secure aggregation, TEEs, or
  verifiable aggregation) — future work.
- **Sybil attacks** beyond the modelled fraction, and dynamic/adaptive
  corruption that reacts to the defence within a round.
- **Inference attacks on the encrypted transport** and side channels.
- **Backdoor/targeted poisoning stealthy enough to pass Multi-Krum** — we test
  overt untargeted and scaling attacks; stealthy targeted backdoors are noted as
  future work.
- **Data-availability / free-rider** gNBs that submit stale-but-honest updates.

---

*This threat model is intentionally aligned with the finalised proposal/deck: a
Byzantine-robust, differentially private federated IDS for 6G RAN, with the
DP × Multi-Krum interaction (RO4) as the distinguishing research contribution.*
