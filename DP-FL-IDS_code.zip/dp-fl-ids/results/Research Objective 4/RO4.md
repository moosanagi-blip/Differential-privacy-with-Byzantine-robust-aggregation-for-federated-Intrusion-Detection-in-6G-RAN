# Research Objective 4 — Cross-component interaction (DP × Multi-Krum)

*Every number and figure in this folder comes from the complete CICIoT2023
corpus: 46,686,579 flows, 37,349,252 used for training and 9,337,327 held out.*

---

## 1. The objective

> **Assess how differential-privacy noise interacts with Byzantine-robust
> aggregation.**

It was to deliver:

1. an examination of whether **Gaussian DP noise disrupts Multi-Krum's
   distance-based scoring**,
2. verification that the fully integrated framework keeps operationally
   acceptable accuracy,
3. testing under **simultaneous DP noise and Byzantine attack**,
4. practical guidelines for configuring the two together.

This objective closes the G1 × G2 intersection — the interaction no prior work
had studied.

**Why the question is not obvious.** Multi-Krum decides who to trust by
measuring distances between client updates: a malicious update sits far from the
consensus, so it gets excluded. Differential privacy works by *adding random
noise to exactly those updates*. If the noise is large enough to scatter honest
updates as far apart as a malicious one, the defence goes blind — and the system
would have to choose between being private and being robust. This objective
tests whether that happens.

---

## 2. How to read the numbers

Every prediction falls into one of four buckets: **TP** (attack, correctly
flagged), **FP** (benign, wrongly flagged — a false alarm), **TN** (benign,
correctly left alone), **FN** (attack, missed).

| metric | formula | what it means in plain language |
|---|---|---|
| **Accuracy** | $\frac{TP+TN}{TP+TN+FP+FN}$ | of every flow, what fraction got the right label. Under attack it is the survival number: a collapsed model scores ~0 |
| **Precision** | $\frac{TP}{TP+FP}$ | when it says "attack", how often is it right |
| **Recall** | $\frac{TP}{TP+FN}$ | of the attacks that really happened, how many it caught |
| **F1** | $2\cdot\frac{P \cdot R}{P+R}$ | harmonic mean of the two — 0, not 0.5, for a model perfect on one and useless on the other |
| **Macro-F1** | $\frac{1}{34}\sum_c F_1^{(c)}$ | F1 averaged with **every one of the 34 classes counting equally**. A poisoned model that survives on the majority classes alone is exposed here |
| **FPR** | $\frac{FP}{FP+TN}$ | of all genuinely benign traffic, what fraction raised an alarm. A collapsed model flags *everything*, so its FPR goes to 1.00 |

Two more that belong to this objective specifically:

- **Poisoned updates admitted** — with 3 malicious gNBs over 30 rounds, **90
  poisoned updates are offered in total**. This counts how many the aggregator
  actually let into the average. It is the sharpest measure of a defence,
  because it is a property of the filter itself rather than of how well the
  model happened to train.
- **Multi-Krum distance score** — the sum of squared distances from each update
  to its nearest neighbours. Multi-Krum keeps the lowest-scoring updates. The
  *ratio* between the malicious and honest mean score is the safety margin the
  defence works with.

---

## 3. What was run

A **sign-flip attack**: malicious gNBs invert the sign of their model update and
amplify it, so it actively drags the global model backwards rather than merely
being useless.

Four aggregation rules × four attack fractions (0 %, 10 %, 20 %, 30 %), 30
rounds each:

| aggregation rule | how it decides |
|---|---|
| **FedAvg** | plain average of all 10 updates — no notion of an outlier |
| **Krum** | picks the single update closest to the crowd; discards the other 9 |
| **Multi-Krum** | scores all updates by distance, averages the most consistent ones |
| **Trimmed-mean** | drops the highest and lowest value per coordinate, averages the rest |

Plus the **interaction run** the objective is named for: Multi-Krum at 30 %
malicious **with differential privacy switched on** (ε = 5), so the filter can be
compared against the identical attack with privacy off.

Common settings: 10 gNBs, non-IID Dirichlet(α = 0.3), MLP, SGD (momentum 0.9,
lr 0.1), 30 rounds, seed 42, CPU.

---

## 4. The result, figure by figure

Each measure gets its own chart, so nothing is squeezed. Six figures.

All four of the first figures share the same **x-axis: the percentage of gNBs
that are malicious — 0 %, 10 %, 20 %, 30 %.** With 10 base stations that is 0, 1,
2 and 3 attackers. Each coloured line is one aggregation rule, and the colours
stay the same in every figure: **FedAvg orange, Krum violet, Multi-Krum blue,
Trimmed-mean green.**

### Figure 1 — accuracy under attack

![Accuracy against the fraction of malicious gNBs, one line per aggregation rule](fig_byz_accuracy.png)

| | |
|---|---|
| **y-axis** | **global test accuracy**, $(TP+TN)/(TP+TN+FP+FN)$ — of all 9,337,327 held-out flows, the fraction labelled correctly. Under attack this is the survival number: a poisoned model drops to ~0 |

**What it shows:** who survives and at what point they stop surviving. Read the
*shape* of each line, not just its endpoint — a rule that falls off a cliff
between two measured points is a rule whose breaking point you have located.

### Figure 2 — macro-F1 under attack

![Macro-F1 against the fraction of malicious gNBs](fig_byz_macro_f1.png)

| | |
|---|---|
| **y-axis** | **macro-F1** — the F1 of each of the 34 classes, averaged with **every class weighted equally**. F1 is $2PR/(P+R)$, the harmonic mean of precision and recall |
| **why a separate chart from accuracy** | a model could survive an attack by collapsing onto the majority class and still post a respectable accuracy. Macro-F1 exposes that, because the rare families would fall to zero |

### Figure 3 — false alarms under attack

![False-positive rate against the fraction of malicious gNBs](fig_byz_fpr.png)

| | |
|---|---|
| **y-axis** | **false-positive rate**, $FP/(FP+TN)$ — of all genuinely benign traffic, the fraction that raised an alarm. **Lower is better** |
| **the tell** | a fully collapsed model flags *everything*, so its FPR pins at exactly 1.00. That flat line at the top is what a dead detector looks like |

### Figure 4 — how many poisoned updates got through

![Poisoned updates admitted by each aggregation rule](fig_byz_admitted.png)

| | |
|---|---|
| **x-axis** | the four aggregation rules |
| **y-axis** | **poisoned updates admitted** — with 3 malicious gNBs over 30 rounds, **90 poisoned updates are offered in total**, and this counts how many actually reached the average. The label on each bar reads *admitted / offered* |

**Why this is the sharpest figure in the objective:** the other three measure how
well a model happened to train, which depends on the data, the optimiser and
luck. This one is a property of the *filter itself*, counted directly from the
campaign's round-by-round record of which client updates were selected. "0 of 90"
is arithmetic, not a claim.

**Accuracy by malicious fraction:**

| aggregation rule | 0 % | 10 % | 20 % | 30 % | poisoned updates admitted (at 30 %) |
|---|---|---|---|---|---|
| FedAvg | 0.892 | **0.000** | **0.000** | **0.000** | 90 / 90 |
| Krum | 0.828 | 0.834 | 0.835 | 0.837 | 0 / 90 |
| **Multi-Krum** | **0.893** | **0.891** | **0.893** | **0.893** | **0 / 90** |
| Trimmed-mean | 0.896 | 0.882 | **0.000** | **0.000** | 90 / 90 |

**Macro-F1 and false alarms at 30 % malicious:**

| aggregation rule | macro-F1 | FPR |
|---|---|---|
| FedAvg | 0.000 | 1.000 |
| Krum | 0.444 | 1.000 |
| **Multi-Krum** | **0.593** | **0.021** |
| Trimmed-mean | 0.000 | 1.000 |

### Figures 5 and 6 — the interaction test: does privacy blind the filter?

These two are the objective's core experiment. The **same attack**, run twice:
once with privacy off, once with privacy on.

![Honest against malicious distance scores per round, privacy off](fig_krum_scores_privacy_off.png)

![Honest against malicious distance scores per round, privacy on](fig_krum_scores_privacy_on.png)

| | |
|---|---|
| **x-axis** | the **communication round**, 1 to 30 |
| **y-axis** | the **mean Multi-Krum distance score**, on a **log scale** — the sum of squared distances from a client's update to its nearest neighbours. Multi-Krum keeps the lowest scorers, so a high score means "this update does not look like the others". Log scale because the two groups are orders of magnitude apart |
| **two lines** | **blue = the 7 honest gNBs**, **red = the 3 malicious ones**, each averaged over its group |
| **the gap between them** | the safety margin the defence works with. It is printed in each title as a multiple |

**How to read the pair:** DP adds random noise to every update, so it pushes both
lines *up* — which is why the privacy-on chart starts higher. The question is
whether it pushes the blue line up far enough to reach the red one. It does not.

| Multi-Krum, 30 % malicious | accuracy | macro-F1 | FPR | poisoned updates admitted | mean score separation |
|---|---|---|---|---|---|
| privacy **off** | 0.893 | 0.593 | 0.021 | **0 / 90** | **70.7×** |
| privacy **on** (ε = 5) | 0.822 | 0.417 | 0.011 | **0 / 90** | **38.2×** |

---

## 5. Analysis

### Poisoned updates admitted — the number that settles the objective

**0 of 90, with privacy off and with privacy on.** This is the cleanest result
in the thesis, because it is not a statistical claim about how well a model
trained — it is a count of what the filter did, extracted from the campaign's own
round-by-round record. Multi-Krum excluded every malicious update in every round
at every attack level, and adding differential privacy changed that count by
nothing.

### Distance separation — why it works, and how much margin there is

The score ratio between malicious and honest updates is **70.7× without privacy
and 38.2× with it**. So DP noise *does* narrow the gap — it roughly halves the
margin — but 38× is still an enormous separation. The noise the ε = 5 guarantee
requires (σ ≈ 0.6) is orders of magnitude smaller than the distance a
sign-flipped update travels.

That is the mechanistic answer to RO4's question, and it generalises: the defence
has margin to spare, so it would survive a considerably tighter privacy budget
before the two mechanisms started to interfere.

### Accuracy — Multi-Krum is flat under attack; the others are not

Multi-Krum posts 0.893 / 0.891 / 0.893 / 0.893 across 0–30 % malicious. Not
"degrades gracefully" — **flat, to three decimals.**

- **FedAvg does not degrade, it collapses.** 0.892 → 0.000 with a *single*
  malicious gNB, admitting every poisoned update. The model ends up predicting
  one class. Averaging has no notion of an outlier, so one determined attacker
  simply wins. This is still the default aggregator in most federated-learning
  work.
- **Trimmed-mean is the instructive failure and worth showing deliberately.** It
  posts the best score in the table with no attackers (0.896) and survives 10 %
  (0.882) — then collapses completely at 20 %. Coordinate-wise trimming removes
  extreme *values*, but a sign-flipped update is not extreme in any single
  coordinate; it is extreme in *direction*. **A defence evaluated only at low
  attack rates tells you almost nothing**, and this row is the proof.
- **Krum is robust but expensive.** It admits 0 of 90 at every level, yet keeps
  one gNB's update per round and discards nine tenths of each round's learning:
  0.828 even unattacked.

### Macro-F1 — confirms the survivors are genuinely healthy

At 30 % malicious, Multi-Krum holds macro-F1 at **0.593** against 0.594 with no
attack. This matters because accuracy alone could hide a model that survived by
collapsing onto the majority class. It did not: the rare classes are as well
served under attack as without it. FedAvg and trimmed-mean sit at 0.000, and
Krum at 0.444 — visibly damaged even though its filter worked, because it throws
away so much data.

### False-positive rate — the operational tell

A collapsed model flags *everything*, so its FPR pins at **1.000** — FedAvg and
trimmed-mean both do this at 30 %. Krum also sits at 1.000 despite excluding
every poisoned update, which is the clearest evidence that a working filter is
not sufficient on its own. **Multi-Krum stays at 0.021 under attack**,
indistinguishable from its 0.022 with no attack. With privacy added it improves
further to 0.011, for the same reason as in RO1: noise makes the model less
willing to raise alarms.

### The cost of running both at once

Privacy plus attack together costs 0.893 → **0.822** accuracy and 0.593 → 0.417
macro-F1. Almost all of that is the DP tax already priced in RO3 (0.893 → 0.839
with no attacker present); the *incremental* cost of the attack, once privacy is
on, is about 1.7 accuracy points. **The two mechanisms compose, and their costs
do not compound.**

### Practical guidelines

1. **Use Multi-Krum.** Not trimmed-mean (fails between 10 % and 20 %), not Krum
   (unusable false-alarm rate), not FedAvg (fails at 10 %).
2. **Leave it on permanently.** It costs nothing without an attack (RO1) and it
   is the difference between 0.893 and 0.000 with one. A defence you must enable
   in advance is a defence you will not have when it matters.
3. **Privacy and robustness can be deployed together, and should be.** The
   filtering margin is 38× at ε = 5 — ample headroom.
4. **Do not evaluate a robust aggregator only at low attack rates.**
   Trimmed-mean looks fine at 10 % and is gone at 20 %.

---

## 6. Files in this folder

| file | what it is |
|---|---|
| `fig_byz_accuracy.png` | accuracy across 0–30 % malicious, per rule |
| `fig_byz_macro_f1.png` | macro-F1 across 0–30 % malicious, per rule |
| `fig_byz_fpr.png` | false-alarm rate across 0–30 % malicious, per rule |
| `fig_byz_admitted.png` | poisoned updates each rule let through |
| `fig_krum_scores_privacy_off.png` | honest vs malicious distance scores, no DP |
| `fig_krum_scores_privacy_on.png` | the same, with DP at ε = 5 |
| `byz_*.json` | the full result of each run — per-round metrics, which clients were malicious, which updates were selected, and the Multi-Krum score behind every decision |
| `byz_multikrum_dp_f30.json` | the interaction run: attack and privacy at the same time |
| `byz_*_timeline.csv` | the same per-round metrics as a spreadsheet |

Regenerate the figures from the run files (trains nothing, takes seconds):

```bash
cd code && python scripts/make_figures.py results
```

Related: the no-attack cost of Multi-Krum is in *Research Objective 1*; the
threat model behind the sign-flip attack is `docs/threat_model.md`; the
aggregation rules are implemented in `code/src/fl/aggregation.py`.
