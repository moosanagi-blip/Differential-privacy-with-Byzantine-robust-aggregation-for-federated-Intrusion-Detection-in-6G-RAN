# DP-FL-IDS — Results

**Privacy-Preserving Federated Learning for Intrusion Detection in 6G Radio
Access Networks — A Byzantine-Robust Differential Privacy Framework**

*Everything in this folder is measured on the complete CICIoT2023 corpus:
**46,686,579 flows**, 37,349,252 used for training and 9,337,327 held out.
Nothing is subsampled.*

---

## How this folder is organised

One folder per Research Objective. Each contains that objective's own write-up —
what the objective was, what was run, the result, and the analysis — together
with its figures and the raw result files behind them.

| folder | objective | read |
|---|---|---|
| **Research Objective 1** | Framework design and implementation | [`RO1.md`](Research%20Objective%201/RO1.md) |
| **Research Objective 2** | Adaptive privacy-budget (ε) scheduling | [`RO2.md`](Research%20Objective%202/RO2.md) |
| **Research Objective 3** | Privacy–utility characterisation | [`RO3.md`](Research%20Objective%203/RO3.md) |
| **Research Objective 4** | Cross-component interaction (DP × Multi-Krum) | [`RO4.md`](Research%20Objective%204/RO4.md) |

At this level: `results_table.csv` and `SUMMARY.md` (every run, one row each),
and `fig_round_time.png` / `fig_round_time_per_round.png`, which span all four
objectives.

---

## The four objectives at a glance

| | question | answer |
|---|---|---|
| **RO1** | Can differential privacy and Multi-Krum be combined into one working framework? | **Yes** — and they compose: DP + Multi-Krum (0.839) scores *above* DP alone (0.810) |
| **RO2** | Does varying ε across rounds beat spending it uniformly? | **Partly, and not as proposed** — the proposal's shape *loses* 14 accuracy points; its inverse gains 3.1, but only on majority classes and at 13× the false alarms |
| **RO3** | What does privacy cost? | **5.3 accuracy points at ε = 5**, monotonic and predictable across ε ∈ {1, 5, 10, 50} |
| **RO4** | Does DP noise blind Multi-Krum's filtering? | **No** — **0 of 90** poisoned updates admitted with privacy on *and* off; the honest/malicious score gap is 70× without DP and still 38× with it |

## Headline numbers

| | value |
|---|---|
| Best non-private detection (FL + Multi-Krum) | **0.893** accuracy · 0.594 macro-F1 · 0.022 FPR |
| Private operating point (ε = 5, worst-case client) | **0.839** accuracy · 0.463 macro-F1 · **0.012** FPR |
| Multi-Krum under a 30 % sign-flip attack | **0.893** — unchanged from no attack; **0/90** poisoned updates admitted |
| Multi-Krum with privacy *and* attack together (ε = 5, 30 %) | **0.822** accuracy · **0/90** admitted — the two mechanisms compose |
| FedAvg under the same attack | **0.000** — collapses at 10 % malicious; 90/90 admitted |
| Trimmed-mean under the same attack | survives 10 % (0.882), **collapses at 20 %** — 90/90 admitted |
| Best ε schedule at a matched budget | decreasing noise: **0.870** accuracy (+3.1) but FPR 0.151 against uniform's 0.012 |
| Cost of a federated round | median **28 s** without privacy, **115 s** with it |

Accuracy is never the honest summary on its own — the corpus is heavily
imbalanced, so macro-F1 and the per-family table in *Research Objective 3*
belong beside it in every sentence.

---

## How the campaign was run

| | |
|---|---|
| Dataset | CICIoT2023, all 46,686,579 flows; 37,349,252 train / 9,337,327 held out |
| Clients | 10 simulated gNBs, non-IID Dirichlet(α = 0.3), shards 1.46 M – 6.94 M rows (4.8× skew) |
| Features | 46 network-flow + 7 synthetic RAN telemetry = 53 dimensions |
| Labels | 34 classes across 8 attack families |
| Model | MLP, 6,786 parameters |
| Optimizer | **DP-SGD** — plain SGD, momentum 0.9, lr 0.1 (the canonical DP-SGD optimizer; Adam's per-coordinate rescaling fights clip-and-noise) |
| Rounds | 30, one local epoch, batch 64 |
| Privacy | (ε, δ)-DP, δ = 1e-5, RDP accounting over a wide α grid, **calibrated for the worst-case (smallest) client** |
| Attack | sign-flip, malicious gNBs invert and amplify their update |
| Compute | CPU, seed 42 |

**Training protocol.** Each shard is cut into 30 disjoint slices and round *r*
trains on slice *r*, so the 30 rounds consume every training row **exactly
once** — verified by reconstructing each shard from its slices byte-identically.
Per-round metrics use a 202,986-row stratified evaluation subset; every final
number is scored on the complete 9,337,327-row held-out set.

**Worst-case privacy calibration.** Under Dirichlet skew the smallest shard
samples at the highest rate and spends the most budget: calibrating against the
*average* shard measured **ε = 10.7 where 5.0 was being reported**. Every run
here calibrates for the worst-case client, so the stated ε holds for every gNB,
and `final_epsilon_worst_client` is recorded in each result file.

## Compute overhead

![Median wall-clock seconds per round, with and without privacy](fig_round_time.png)

![Per-round wall-clock across a run, for the four framework configurations](fig_round_time_per_round.png)

In the first figure the **x-axis** is simply *privacy off* against *privacy on*,
the **y-axis** is wall-clock seconds for one federated round, the bars are the
median and each hollow dot is one run. In the second the **x-axis** is the
communication round and each line is one configuration.

A federated round costs a **median 28 s without DP and 115 s with it — privacy
costs ×4.0 per round**. That is the price of per-sample gradient clipping: the
same arithmetic done once per record instead of once per batch. The spread
within each group, and the spikes in the second figure, are contention on a
shared CPU rather than a property of any configuration, which is why the median
across runs is quoted instead of one bar per configuration.

## The six evaluation dimensions

The proposal defence committed to six. Where each is reported:

| # | dimension | reported in | figure |
|---|---|---|---|
| 1 | Detection accuracy: macro-F1, per-class recall, FPR | RO1, RO3 | `fig_ablation_accuracy.png`, `fig_ablation_macro_f1.png`, `fig_ablation_fpr.png`, `fig_privacy_utility.png`, `fig_fpr_vs_epsilon.png`, `fig_per_category.png` |
| 2 | Privacy spend: cumulative ε via Rényi accountant | RO2 | `fig_privacy_spend.png`, `fig_noise_schedule.png`, `fig_sigma_vs_epsilon.png` |
| 3 | Byzantine robustness: degradation vs malicious fraction | RO4 | `fig_byz_accuracy.png`, `fig_byz_macro_f1.png`, `fig_byz_fpr.png`, `fig_byz_admitted.png` |
| 3b | Robustness *and* privacy at once (the RO4 interaction test) | RO4 | `fig_krum_scores_privacy_off.png`, `fig_krum_scores_privacy_on.png` |
| 4 | Convergence speed | RO1, RO2, RO3 | `fig_convergence_*.png`, `fig_schedule_*.png`, `fig_eps_convergence_*.png` |
| 5 | Ablation contribution: Δ on component removal | RO1 | `fig_ablation_accuracy.png`, `fig_ablation_macro_f1.png` |
| 6 | Compute overhead: per-round wall-clock | this file | `fig_round_time.png`, `fig_round_time_per_round.png` |

**On convergence speed:** the campaign records a `conv_round` field that counts
rounds to an *absolute* 0.9 accuracy, which this 34-class task never reaches, so
it is empty in every run. The usable measure — and the one reported — is rounds
to **90 % of the run's own final accuracy**, recorded as
`conv_round_90pct_final` in `results_table.csv`. Every configuration that learns
gets there by **round 2**; the tightest budget, ε = 1, takes 6.

---

## Limitations & threats to validity (state these proactively in the defense)

**Synthetic RAN telemetry.** No public intrusion-detection dataset captures
6G O-RAN radio-layer traffic, so the 7 RAN features (RSRP, SINR, RSRQ, PRB
utilisation, handover rate, beam-failure count, throughput) are **synthetically
generated and attack-conditioned**, then fused with the real CICIoT2023 network-
flow features. They are a **methodological scaffold** for the 6G-RAN framing, *not*
measured 6G traffic: the contribution is the privacy-preserving, Byzantine-robust
FL *framework and its evaluation methodology*, which transfers directly to real
gNB telemetry when such data becomes available. This is an explicit, owned
limitation — the DP, Multi-Krum, and FL mechanisms are dataset-agnostic and would
operate identically on real RAN features. (Frame it first; don't wait to be asked.)

**Rare-class imbalance — the substantive limitation.** The corpus
is roughly **6000:1** between `DDoS-ICMP_Flood` (~6M rows) and the rarest
classes (~1–3k), and *more data makes this worse, not better*: at full scale the
Injection family (2,901 test rows, 0.03 % of the held-out set) reaches **0.000
recall** and Malware_BF (4,680 rows) reaches 0.240, while the six larger families
score 0.647–0.999. Accuracy of 0.892 is therefore driven by the majority
families and must never be quoted alone — macro-F1 (0.570) and the per-category
table are the honest summary. Addressing this needs class-rebalancing,
cost-sensitive loss or few-shot methods, none of which are in scope here; it is
the clearest direction for follow-on work. This is an inherent property of the
34-way fine-grained,
imbalanced task; the coarse **8-category** view is much stronger and is the
recommended operational reporting granularity.

**Adaptive-ε (RO2).** The schedule *shape* does change the outcome at a matched
budget, but not as the proposal predicted: relaxing early and tightening late —
the shape the objective was written on — costs 14 accuracy points, while its
inverse gains 3.1. That gain is confined to the majority classes (macro-F1 is
flat) and costs a 13× rise in false alarms, so uniform allocation remains the
recommended operating point. The result is three schedule shapes at one budget,
one architecture, one seed: the direction is mechanically explainable, the
magnitude should not be quoted as a general law.

---

## Reproducing

```bash
cd code
python main.py --campaign                    # the full-corpus campaign (resumable)
python scripts/make_figures.py results       # every figure, from saved results, in seconds
python scripts/rebuild_summary.py results    # results_table.csv + SUMMARY.md
python main.py --replay                      # narrate the finished results, train nothing
```

Figures are rebuilt from the per-run JSON files, never from a fresh training
run, so a new plot costs seconds rather than hours. Results are seed-fixed (42)
and deterministic given the device.
