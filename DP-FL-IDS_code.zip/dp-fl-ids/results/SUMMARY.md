# DP-FL-IDS — Experiment Summary

Reported campaign: complete CICIoT2023 corpus (46,686,579 flows), MLP, DP-SGD, 30 chunked rounds, epsilon calibrated for the worst-case client, seed 42, CPU. Runs are filed by Research Objective.

| name | aggregator | dp | epsilon | byz_fraction | attack | accuracy | macro_f1 | fpr | conv_round | conv_round_90pct_final | round_time_s | macro_precision | macro_recall |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ablation_fl_dp | fedavg | True | 5.0010 | 0.0000 | none | 0.8101 | 0.4606 | 0.0086 | None | 2 | 141.8500 | 0.5273 | 0.4684 |
| ablation_fl_dp_krum | multikrum | True | 5.0010 | 0.0000 | none | 0.8391 | 0.4627 | 0.0116 | None | 2 | 114.6700 | 0.5225 | 0.4842 |
| ablation_fl_krum | multikrum | False | 0.0000 | 0.0000 | none | 0.8926 | 0.5940 | 0.0222 | None | 2 | 28.2000 | 0.6512 | 0.6003 |
| ablation_fl_only | fedavg | False | 0.0000 | 0.0000 | none | 0.8916 | 0.5701 | 0.0185 | None | 2 | 100.2700 | 0.6413 | 0.5878 |
| pu_eps1 | multikrum | True | 0.9920 | 0.0000 | none | 0.8136 | 0.4260 | 0.3080 | None | 6 | 125.9400 | 0.4820 | 0.4619 |
| pu_eps10 | multikrum | True | 10.0580 | 0.0000 | none | 0.8535 | 0.4697 | 0.0316 | None | 2 | 108.8500 | 0.4814 | 0.4934 |
| pu_eps5 | multikrum | True | 5.0010 | 0.0000 | none | 0.8391 | 0.4627 | 0.0116 | None | 2 | 114.6700 | 0.5225 | 0.4842 |
| pu_eps50 | multikrum | True | 49.9840 | 0.0000 | none | 0.8831 | 0.4930 | 0.0489 | None | 2 | 105.3300 | 0.5279 | 0.5155 |
| byz_fedavg_f0 | fedavg | False | 0.0000 | 0.0000 | sign_flip | 0.8916 | 0.5701 | 0.0185 | None | 2 | 25.0100 | 0.6413 | 0.5878 |
| byz_fedavg_f10 | fedavg | False | 0.0000 | 0.1000 | sign_flip | 0.0001 | 0.0000 | 1.0000 | None | 1 | 23.7300 | 0.0000 | 0.0294 |
| byz_fedavg_f20 | fedavg | False | 0.0000 | 0.2000 | sign_flip | 0.0001 | 0.0000 | 1.0000 | None | 1 | 23.2500 | 0.0000 | 0.0294 |
| byz_fedavg_f30 | fedavg | False | 0.0000 | 0.3000 | sign_flip | 0.0001 | 0.0000 | 1.0000 | None | 1 | 24.3200 | 0.0000 | 0.0294 |
| byz_krum_f0 | krum | False | 0.0000 | 0.0000 | sign_flip | 0.8279 | 0.4677 | 0.9333 | None | 2 | 23.8600 | 0.5403 | 0.5125 |
| byz_krum_f10 | krum | False | 0.0000 | 0.1000 | sign_flip | 0.8342 | 0.4713 | 0.8669 | None | 2 | 23.6200 | 0.5748 | 0.5188 |
| byz_krum_f20 | krum | False | 0.0000 | 0.2000 | sign_flip | 0.8354 | 0.4489 | 0.8849 | None | 2 | 24.7000 | 0.5179 | 0.5006 |
| byz_krum_f30 | krum | False | 0.0000 | 0.3000 | sign_flip | 0.8375 | 0.4439 | 1.0000 | None | 10 | 25.2000 | 0.4418 | 0.5042 |
| byz_multikrum_dp_f30 | multikrum | True | 5.0010 | 0.3000 | sign_flip | 0.8218 | 0.4160 | 0.0111 | None | 2 | 105.0400 | 0.4973 | 0.4432 |
| byz_multikrum_f0 | multikrum | False | 0.0000 | 0.0000 | sign_flip | 0.8926 | 0.5940 | 0.0222 | None | 2 | 23.8200 | 0.6512 | 0.6003 |
| byz_multikrum_f10 | multikrum | False | 0.0000 | 0.1000 | sign_flip | 0.8908 | 0.5922 | 0.0218 | None | 2 | 23.2700 | 0.6489 | 0.6000 |
| byz_multikrum_f20 | multikrum | False | 0.0000 | 0.2000 | sign_flip | 0.8928 | 0.5734 | 0.0137 | None | 2 | 22.0700 | 0.6328 | 0.5770 |
| byz_multikrum_f30 | multikrum | False | 0.0000 | 0.3000 | sign_flip | 0.8933 | 0.5929 | 0.0212 | None | 2 | 23.3800 | 0.6498 | 0.6026 |
| byz_trimmedmean_f0 | trimmedmean | False | 0.0000 | 0.0000 | sign_flip | 0.8959 | 0.5868 | 0.0232 | None | 2 | 22.4000 | 0.6358 | 0.5959 |
| byz_trimmedmean_f10 | trimmedmean | False | 0.0000 | 0.1000 | sign_flip | 0.8817 | 0.5727 | 0.0474 | None | 2 | 24.1400 | 0.6278 | 0.5827 |
| byz_trimmedmean_f20 | trimmedmean | False | 0.0000 | 0.2000 | sign_flip | 0.0001 | 0.0000 | 1.0000 | None | 1 | 24.0800 | 0.0000 | 0.0294 |
| byz_trimmedmean_f30 | trimmedmean | False | 0.0000 | 0.3000 | sign_flip | 0.0001 | 0.0000 | 1.0000 | None | 1 | 23.9300 | 0.0000 | 0.0294 |
| eps_decreasing | multikrum | True | 4.9550 | 0.0000 | none | 0.8699 | 0.4590 | 0.1505 | None | 10 | 119.2800 | 0.4754 | 0.4847 |
| eps_increasing | multikrum | True | 4.9550 | 0.0000 | none | 0.6995 | 0.3193 | 0.0444 | None | 2 | 102.9300 | 0.3363 | 0.3508 |
| eps_static | multikrum | True | 5.0010 | 0.0000 | none | 0.8391 | 0.4627 | 0.0116 | None | 2 | 114.6700 | 0.5225 | 0.4842 |