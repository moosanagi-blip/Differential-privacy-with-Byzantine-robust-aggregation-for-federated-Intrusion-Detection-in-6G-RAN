# Research Objective 1 — Framework design and implementation

*Every number and figure in this folder comes from the complete CICIoT2023
corpus: 46,686,579 flows, 37,349,252 used for training and 9,337,327 held out.*

---

## 1. The objective

> **Design and implement a privacy-preserving federated learning framework for
> intrusion detection in 6G O-RAN.**

It was to deliver four things:

1. **(ε, δ)-differential privacy** via the Gaussian mechanism with per-sample
   gradient clipping,
2. **Multi-Krum Byzantine-robust aggregation** with formal tolerance guarantees,
3. a **6G RAN threat model** spanning network-layer and radio-layer attack
   vectors (`docs/threat_model.md`),
4. a **6G feature taxonomy** merging IP-flow observables with RAN telemetry.

This objective closes research gaps G1 (gradient-based privacy leakage), G2
(Byzantine vulnerability) and G3 (no 6G-specific threat model).

The question it has to answer is not "does federated learning work" — that is
known. It is **whether differential privacy and Multi-Krum can be put in the
same system without breaking each other.** Both mechanisms interfere with the
model update: DP adds calibrated noise to it, Multi-Krum throws some updates
away entirely. If they conflict, the framework has to give up one of them.

---

## 2. How to read the numbers

Every prediction the detector makes falls into one of four buckets. For a given
attack class:

| | the flow really is an attack | the flow really is benign |
|---|---|---|
| **flagged as attack** | **TP** — true positive (caught it) | **FP** — false positive (false alarm) |
| **left alone** | **FN** — false negative (missed it) | **TN** — true negative (correct) |

Every metric in this thesis is arithmetic on those four counts.

### Accuracy

$$\text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN}$$

**Of every flow in the test set, what fraction got the right label?** The most
intuitive number, and the most misleading one here: this corpus is dominated by
DDoS traffic (6.8 M of the 9.3 M held-out rows), so a model that only learned
DDoS well would still post a high accuracy. It is never quoted alone in this
work.

### Precision, recall, and F1 (per class)

$$\text{Precision} = \frac{TP}{TP + FP} \qquad \text{Recall} = \frac{TP}{TP + FN} \qquad F_1 = 2 \cdot \frac{P \cdot R}{P + R}$$

- **Precision** — when the detector says *"this is a DDoS flow"*, how often is it
  right? Low precision means crying wolf.
- **Recall** — of all the DDoS flows that really existed, how many did it catch?
  Low recall means attacks slipping through.
- **F1** — the harmonic mean of the two. It is deliberately unforgiving: a model
  that scores 1.0 on one and 0.0 on the other gets an F1 of 0, not 0.5. You
  cannot game it by flagging everything, or by flagging nothing.

### Macro-F1 — the honest headline

$$\text{Macro-}F_1 = \frac{1}{C}\sum_{c=1}^{C} F_1^{(c)} \qquad (C = 34 \text{ classes})$$

The F1 of each class, averaged with **every class counting equally** — the
Injection family with 2,901 test rows counts exactly as much as DDoS with
6.8 million. This is why macro-F1 sits far below accuracy throughout this work:
**the gap between them is the class-imbalance problem, stated numerically.**
Macro-precision and macro-recall are averaged the same way.

### False-positive rate (FPR)

$$\text{FPR} = \frac{FP}{FP + TN} = \frac{\text{benign flows wrongly flagged}}{\text{all benign flows}}$$

**Of all the genuinely benign traffic, what fraction did the detector raise an
alarm on?** For an operator this is the single most important number after
detection itself: an IDS that floods the console with false alarms gets switched
off, and then it detects nothing at all. Lower is better.

### Convergence speed

How many communication rounds until the model stops meaningfully improving —
measured here as the first round reaching **90 % of that run's own final
accuracy**. It matters because every round costs bandwidth from ten base
stations and wall-clock time.

---

## 3. What was run

Four configurations, each adding one mechanism to the one before it, so every
difference isolates one component:

| run | aggregation | privacy |
|---|---|---|
| `ablation_fl_only` | FedAvg | none |
| `ablation_fl_dp` | FedAvg | DP, ε = 5 |
| `ablation_fl_krum` | Multi-Krum | none |
| `ablation_fl_dp_krum` | Multi-Krum | DP, ε = 5 |

Common settings: 10 simulated gNBs, non-IID Dirichlet(α = 0.3) shards (1.46 M –
6.94 M rows, 4.8× skew), MLP with 6,786 parameters, DP-SGD (SGD, momentum 0.9,
lr 0.1), 30 rounds, batch 64, δ = 1e-5, seed 42, CPU. No attackers in any of
these runs — RO1 asks what the components cost, not how they behave under
attack.

**Training protocol.** Each shard is cut into 30 disjoint slices and round *r*
trains on slice *r*, so the 30 rounds consume every training row **exactly
once** (verified by reconstructing each shard from its slices byte-identically).
Per-round metrics use a 202,986-row stratified subset; the final numbers below
are scored on the complete 9,337,327-row held-out set.

**Privacy calibration.** ε is calibrated for the **worst-case (smallest)
client**. Under Dirichlet skew the smallest shard samples at the highest rate
and spends the most budget — calibrating against the average shard measured
ε = 10.7 where 5.0 was being reported. The quoted ε therefore holds for *every*
gNB, not the average one.

---

## 4. The result, figure by figure

Each measure gets its own chart, so nothing is squeezed. Six figures.

### Figure 1 — accuracy by configuration

![Accuracy for each configuration, with the change against FL-only annotated](fig_ablation_accuracy.png)

| | |
|---|---|
| **x-axis** | the four **configurations**, read as a ladder: each adds one mechanism to the one on its left |
| **y-axis** | **global test accuracy**, $(TP+TN)/(TP+TN+FP+FN)$ — of all 9,337,327 held-out flows, the fraction labelled correctly. 0 = useless, 1 = perfect |
| **the bars** | one per configuration, with the value printed on top |
| **Δ labels** | the change against "FL only", which is what an ablation actually measures — what does *adding this component* cost or contribute |

### Figure 2 — macro-F1 by configuration

![Macro-F1 for each configuration, with the change against FL-only annotated](fig_ablation_macro_f1.png)

| | |
|---|---|
| **x-axis** | the same four configurations |
| **y-axis** | **macro-F1** — the F1 score of each of the 34 attack classes, averaged with **every class weighted equally**. F1 is $2PR/(P+R)$, the harmonic mean of precision and recall; it scores 0, not 0.5, for a detector perfect at one and useless at the other |
| **why a separate chart** | macro-F1 and accuracy answer different questions. Accuracy is dominated by DDoS (6.8 M of 9.3 M test rows); macro-F1 gives the 2,901-row Injection family exactly the same weight. **The gap between the two charts is the class-imbalance problem** |

### Figure 3 — false-alarm rate by configuration

![False-positive rate for each configuration](fig_ablation_fpr.png)

| | |
|---|---|
| **x-axis** | the same four configurations |
| **y-axis** | **false-positive rate**, $FP/(FP+TN)$ — of all genuinely benign traffic, the fraction that raised an alarm. **Lower is better**, which is why the bars are red and the axis says so |
| **why it matters** | this is the number an operator feels daily. An IDS that floods the console with false alarms gets muted, and then it detects nothing at all |

| configuration | accuracy | macro-F1 | macro-precision | macro-recall | FPR | ε |
|---|---|---|---|---|---|---|
| FL only | 0.892 | 0.570 | 0.641 | 0.588 | 0.019 | – |
| FL + DP | 0.810 | 0.461 | 0.527 | 0.468 | **0.009** | 5.00 |
| FL + Multi-Krum | **0.893** | **0.594** | **0.651** | **0.600** | 0.022 | – |
| **FL + DP + Multi-Krum** | 0.839 | 0.463 | 0.523 | 0.484 | 0.012 | 5.00 |

### Figures 4, 5 and 6 — what happens round by round

![Accuracy per round for the four configurations](fig_convergence_accuracy.png)

![Macro-F1 per round for the four configurations](fig_convergence_macro_f1.png)

![Training loss per round for the four configurations](fig_convergence_loss.png)

All three share the same **x-axis: the communication round, 1 to 30.** One round
is a full cycle — the server sends the model out, all ten gNBs train on their own
data, the updates come back, and the aggregator combines them into the next
model. Each coloured line is one configuration.

| figure | y-axis | what it is |
|---|---|---|
| **4** | global test accuracy | measured on held-out data after each round. The **circle** marks the first round reaching 90 % of that run's own final accuracy — the convergence-speed number |
| **5** | macro-F1 | the same per-round evaluation, weighted equally across all 34 classes |
| **6** | cross-entropy loss | what the optimiser is actually minimising during local training. Lower is better. Unlike the first two, this is measured on *training* data, so it shows what the optimiser sees rather than what the detector achieves |

---

## 5. Analysis

### The composition test — the point of this objective

Adding Multi-Krum on top of DP moves accuracy from 0.810 to **0.839**. The
combination is *better* than DP alone, not worse. Had the two mechanisms
interfered, that row would sit below the DP-only row and the framework would
have had to choose one or the other. It does not have to.

The reason is visible in RO4: Multi-Krum scores updates by distance and drops
the ones furthest from the consensus. With honest clients under DP, the furthest
updates are simply the noisiest ones — so filtering acts as mild variance
reduction rather than a tax. **RO1 holds at full scale.**

### Accuracy — what privacy costs, and against what

Two honest numbers, depending on which comparison you make:

- against plain FedAvg: **8.2 points** (0.892 → 0.810)
- against the Multi-Krum arm — the framework as actually proposed:
  **5.3 points** (0.893 → 0.839)

Quote 5.3 when describing the framework, 8.2 when describing DP on bare FedAvg,
and always say which. **Robustness itself is free:** 0.892 → 0.893. That matters
operationally, because Multi-Krum discards 3 of 10 updates every round and so
*could* have cost accuracy in the normal case. An aggregator you only dare
enable once you already know you are under attack would be useless.

### Macro-F1 — where privacy really bites

Macro-F1 falls **0.570 → 0.461** under DP, proportionally much further than
accuracy (a 19 % relative drop against 9 %). That difference is the whole story
of what DP noise does to a rare class: gradients from a class with a few
thousand examples are small, and clipping plus Gaussian noise drowns them out
first. The majority classes have enough signal to survive the noise; the rare
ones do not.

Multi-Krum lifts macro-F1 in both arms (0.570 → 0.594 without DP, 0.461 → 0.463
with it), which is the same variance-reduction effect showing up where it is
most needed.

### Precision and recall — the model gets more cautious, not more wrong

Under DP, macro-precision falls 0.641 → 0.527 and macro-recall 0.588 → 0.468.
Both drop, and they drop together, which tells you the noise is degrading the
decision boundary uniformly rather than biasing the model toward over- or
under-flagging. If recall had collapsed while precision held, the private model
would be quietly missing attacks — it is not doing that.

### False-positive rate — privacy makes the detector *quieter*

The FPR **improves** under DP, 0.019 → 0.009. This is not an accident and it is
worth saying out loud in a defence: the noise makes the model less confident,
and a less confident model raises fewer alarms on benign traffic. Multi-Krum
alone nudges it the other way (0.019 → 0.022) because a sharper model flags more.
The full framework lands at 0.012 — **below the non-private baseline.** So the
privacy mechanism buys a formal guarantee *and* a quieter console, and only the
detection metrics pay for it.

### Convergence — privacy costs the ceiling, not the climb

Every configuration is within 10 % of its own final accuracy by **round 2**,
with or without privacy. The loss curves separate cleanly: the two private runs
sit at roughly double the loss of the non-private ones and stay noisier
round-to-round, which is the injected noise showing up directly. But they
*converge just as fast*. DP does not make the system take longer to train; it
lowers where it ends up.

---

## 6. Files in this folder

| file | what it is |
|---|---|
| `fig_ablation_accuracy.png` | accuracy by configuration, with Δ against FL-only |
| `fig_ablation_macro_f1.png` | macro-F1 by configuration, with Δ against FL-only |
| `fig_ablation_fpr.png` | false-alarm rate by configuration |
| `fig_convergence_accuracy.png` | accuracy per round |
| `fig_convergence_macro_f1.png` | macro-F1 per round |
| `fig_convergence_loss.png` | training loss per round |
| `ablation_*.json` | the full result of each run — every per-round metric, the config it ran with, and the final scores |
| `ablation_*_timeline.csv` | the same per-round metrics as a spreadsheet |

Regenerate the figures from the run files (trains nothing, takes seconds):

```bash
cd code && python scripts/make_figures.py results
```

Related: the threat model and feature taxonomy this objective also delivers are
in `docs/threat_model.md`; per-round compute cost is in
`../fig_round_time.png`.
