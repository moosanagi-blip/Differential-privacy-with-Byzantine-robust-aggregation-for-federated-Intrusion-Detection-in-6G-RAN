# Research Objective 2 — Adaptive privacy-budget (ε) scheduling

*Every number and figure in this folder comes from the complete CICIoT2023
corpus: 46,686,579 flows, 37,349,252 used for training and 9,337,327 held out.*

---

## 1. The objective

> **Propose, implement and evaluate an adaptive ε-scheduling mechanism for
> DP-FL-IDS.**

It was to deliver:

1. dynamic allocation of the privacy budget ε **across training rounds** (the
   proposal's example: 10 → 5 → 1),
2. optimisation of the privacy–utility trade-off **at a fixed total budget**,
3. a test of whether adaptive ε beats static ε on detection accuracy,
4. validation — **or bounding** — of the claimed advantage.

This objective closes gap G4 and is the proposal's central novelty: adaptive ε
scheduling had never been investigated for an FL-IDS.

**The idea, and why it is plausible.** Differential privacy hides individual
records by adding random noise to each model update. Spending more budget in a
round means less noise that round. The proposal's hypothesis was that early
rounds are convergence-critical and deserve the bigger share — spend ε
generously while the model is learning fast, then tighten as it stabilises. That
is a **decreasing ε** schedule, which is the same thing as an **increasing
noise** schedule.

Point 4 is the one that matters scientifically. An adaptive schedule that
quietly under-spends its budget will always look better, because it is simply
buying accuracy with privacy it never accounted for. Every schedule here is
calibrated by RDP composition to spend the **same total ε**, so the comparison
is fair by construction rather than by assumption.

---

## 2. How to read the numbers

Every prediction falls into one of four buckets: **TP** (attack, correctly
flagged), **FP** (benign, wrongly flagged — a false alarm), **TN** (benign,
correctly left alone), **FN** (attack, missed).

| metric | formula | what it means in plain language |
|---|---|---|
| **Accuracy** | $\frac{TP+TN}{TP+TN+FP+FN}$ | of every flow, what fraction got the right label. Dominated by DDoS, which is 6.8 M of the 9.3 M test rows — never quote it alone |
| **Precision** | $\frac{TP}{TP+FP}$ | when it says "attack", how often is it right |
| **Recall** | $\frac{TP}{TP+FN}$ | of the attacks that really happened, how many it caught |
| **F1** | $2\cdot\frac{P \cdot R}{P+R}$ | harmonic mean of the two — scores 0, not 0.5, for a model that is perfect on one and useless on the other |
| **Macro-F1** | $\frac{1}{34}\sum_c F_1^{(c)}$ | F1 averaged with **every one of the 34 classes counting equally**, so a 2,901-row family weighs as much as a 6.8 M-row one. The gap between this and accuracy *is* the class-imbalance problem |
| **FPR** | $\frac{FP}{FP+TN}$ | of all genuinely benign traffic, what fraction raised an alarm. An IDS that floods the console gets switched off — lower is better |

And two that are specific to this objective:

- **ε (epsilon)** — the privacy budget. It bounds how much any single record can
  influence the released model: smaller ε is a stronger guarantee. Here the
  total across all 30 rounds is fixed at 5.
- **σ (sigma)** — the noise multiplier actually applied in a round. σ is what
  the accuracy pays; ε is what it buys. A schedule is a *shape* for σ over the
  30 rounds.

---

## 3. What was run

Three noise shapes, one budget:

| run | σ, first round → last | ε spent |
|---|---|---|
| `eps_static` | 0.60 → 0.60 (uniform) | 5.001 |
| `eps_decreasing` | **1.51 → 0.50** — loud early, quiet late | 4.955 |
| `eps_increasing` | **0.50 → 1.51** — quiet early, loud late *(the proposal's shape)* | 4.955 |

FL + DP + Multi-Krum, no attackers, 10 gNBs, non-IID Dirichlet(α = 0.3), MLP,
DP-SGD (SGD momentum 0.9, lr 0.1), 30 rounds, δ = 1e-5, seed 42, CPU. ε is
accounted by Rényi differential privacy and calibrated for the worst-case
(smallest) client.

The two adaptive schedules spend **4.955 against static's 5.001 — 0.9 % less
budget, not more.** Neither of them is being subsidised by unaccounted privacy.

---

## 4. The result, figure by figure

Each measure gets its own chart, so nothing is squeezed. Four figures.

### Figure 1 — the three schedules themselves

![The noise multiplier applied in each round, for the three schedules](fig_noise_schedule.png)

| | |
|---|---|
| **x-axis** | the **communication round**, 1 to 30. One round = server sends the model → 10 gNBs train locally → updates come back → Multi-Krum aggregates them |
| **y-axis** | **σ (sigma), the noise multiplier** applied in that round — how much Gaussian noise each gNB adds to its update before sending it. Higher σ = stronger privacy that round, and a blurrier update |
| **three lines** | the three schedule *shapes* being compared. This figure is the independent variable of the whole objective — everything else is a consequence of it |

- **static** (blue, flat at 0.60) — the same noise every round.
- **decreasing** (orange, 1.51 → 0.50) — loud early, quiet late.
- **increasing** (aqua, 0.50 → 1.51) — quiet early, loud late. **This is the
  shape the proposal argued for.**

### Figure 2 — the budget they all spend

![Cumulative privacy spend per round, for the three schedules](fig_privacy_spend.png)

| | |
|---|---|
| **x-axis** | the same communication round, 1 to 30 |
| **y-axis** | **cumulative ε spent so far**, log scale — the running total the Rényi accountant says has been consumed by the end of that round. It only ever goes up: privacy is spent, never refunded |
| **three lines** | the same three schedules |

**What it shows, and why it is the fairness check:** the three curves take
completely different paths — the decreasing schedule spends almost nothing early
and accelerates; the increasing schedule front-loads — yet **they converge on the
same total by round 30**. That is the calibration machinery working, and it is
what makes the comparison budget-fair by construction rather than by assumption.
Without this figure, a schedule that quietly under-spent could show a "gain" that
was really a privacy leak.

| schedule | σ, first → last | accuracy | macro-F1 | macro-precision | macro-recall | FPR | ε spent |
|---|---|---|---|---|---|---|---|
| static (uniform) | 0.60 → 0.60 | 0.839 | **0.461** | **0.523** | 0.484 | **0.012** | 5.001 |
| **decreasing** | 1.51 → 0.50 | **0.870** | 0.459 | 0.475 | **0.485** | 0.151 | 4.955 |
| increasing *(proposal's shape)* | 0.50 → 1.51 | 0.700 | 0.320 | 0.336 | 0.351 | 0.044 | 4.955 |

The metrics in that table, in one line each: **accuracy** = fraction of all flows
labelled correctly; **macro-F1** = the F1 of each of the 34 classes averaged with
every class weighted equally, so rare families count as much as DDoS;
**macro-precision** = when it says "attack", how often it is right;
**macro-recall** = of the real attacks, how many it caught; **FPR** = of genuinely
benign traffic, the fraction that raised an alarm (lower is better).

### Figures 3 and 4 — what the schedules do round by round

![Accuracy per round, by noise schedule](fig_schedule_accuracy.png)

![Macro-F1 per round, by noise schedule](fig_schedule_macro_f1.png)

| | |
|---|---|
| **x-axis** | the communication round, 1 to 30 |
| **y-axis** | **accuracy** in Figure 3, **macro-F1** in Figure 4, both measured on held-out data after each round |
| **three lines** | the same three schedules |
| **the circle** | on Figure 3, the first round reaching 90 % of that run's own final accuracy |

**What they show:** the *shape* of the learning, not just its endpoint. The
decreasing schedule starts worst — it is drowning in σ = 1.51 noise for the first
rounds — and overtakes as its noise falls away. The increasing schedule does the
reverse: it starts strong and is dragged down as its noise rises. Read together
with Figure 1, this is the mechanism behind the whole result.

---

## 5. Analysis

### The headline: the shape matters, but not the way the proposal predicted

**The proposal's own hypothesis is refuted, and its inverse is the one that
helps.** Spending ε generously early and tightening later — the `increasing
noise` row, the 10 → 5 → 1 shape written into the objective — is by far the
**worst** of the three: 0.700 accuracy against static's 0.839, a loss of 14
points at an identical budget. The opposite shape, loud early and quiet late,
is the only one that beats uniform on accuracy.

The reason is that the *last* rounds are the ones that matter, not the first. A
federated model reaches 90 % of its final accuracy by round 2 (see RO1) and
spends the remaining 28 rounds refining. Noise applied to a coarse early model
is largely washed out by subsequent training; noise applied at the end is
baked into the model that gets deployed. Spending the budget so the final
rounds are quietest is therefore the sensible allocation — and it is the reverse
of the intuition the objective was written on.

### Accuracy — decreasing noise wins by 3.1 points

0.839 → **0.870** at a matched (in fact slightly smaller) budget. This is a real
effect, well outside the run-to-run variation of a deterministic seeded run, and
it is the strongest case for adaptive scheduling in this thesis.

### Macro-F1 — and the gain evaporates

0.461 → **0.459**. Unchanged, in fact fractionally lower. This is the number
that decides how the result should be reported. **All 3.1 points of the accuracy
gain came from the majority classes** — DDoS, DoS, Mirai — and none of it
reached the rare families that macro-F1 weights equally. The schedule did not
make the detector better; it made it better *at the traffic it was already good
at*.

### Precision and recall — the model got looser, not sharper

Macro-recall is flat (0.484 → 0.485) while macro-precision falls (0.523 →
0.475). The decreasing schedule catches no more attacks than uniform noise; it
simply says "attack" more often. That is the signature of a lowered decision
threshold, not of a better-trained model.

### False-positive rate — the reason to be cautious

**0.012 → 0.151, a 13× increase in false alarms.** Uniform noise raises an alarm
on 1.2 % of benign traffic; the decreasing schedule raises one on 15 % of it. On
219,639 benign test flows that is the difference between about 2,500 and about
33,000 false alarms. For an operator, that is the difference between a usable
console and one that gets muted.

### The verdict for the thesis

State it in this order, and it is both honest and interesting:

1. **The proposal's schedule (relax early, tighten late) is refuted** — it costs
   14 accuracy points at a matched budget.
2. **The inverse schedule genuinely does beat uniform on accuracy** (+3.1
   points), so scheduling is not a dead end, and the claimed advantage is
   *bounded* rather than dismissed — which is exactly what deliverable 4 asked
   for.
3. **The gain does not survive the metrics that matter operationally.** Macro-F1
   is flat and false alarms rise 13×, so **uniform allocation remains the
   recommended operating point**, and the reported campaign uses it.

This is a stronger contribution than either a clean win or a flat negative. The
mechanism is implemented, correctly calibrated, and characterised: we now know
*which* shape helps, *how much*, and *what it costs* — and that the intuition
the field would reach for first is the wrong one.

### A caveat to state before you are asked

These are three schedule shapes at one budget (ε = 5), on one architecture, at
one seed. The direction of the effect is clear and mechanically explainable, but
the magnitude should not be quoted as a general law. A wider sweep — more
shapes, more budgets, several seeds — is the obvious next step, and
`scripts/tune_adaptive_eps.py` exists to run it.

---

## 6. Files in this folder

| file | what it is |
|---|---|
| `fig_noise_schedule.png` | the σ applied in each round — the three shapes |
| `fig_privacy_spend.png` | cumulative ε per round — the fairness check |
| `fig_schedule_accuracy.png` | accuracy per round, by schedule |
| `fig_schedule_macro_f1.png` | macro-F1 per round, by schedule |
| `eps_*.json` | the full result of each run — every per-round metric, the σ actually applied in each round, the config, and the final scores |
| `eps_*_timeline.csv` | the same per-round metrics as a spreadsheet |

Regenerate the figures from the run files (trains nothing, takes seconds):

```bash
cd code && python scripts/make_figures.py results
```

The scheduler itself is `code/src/privacy/adaptive_eps.py`; the calibration that
forces every shape onto the same total budget is in
`code/src/privacy/dp_engine.py`.
