# Research Objective 3 — Privacy–utility characterisation

*Every number and figure in this folder comes from the complete CICIoT2023
corpus: 46,686,579 flows, 37,349,252 used for training and 9,337,327 held out.*

---

## 1. The objective

> **Empirically characterise the privacy–utility trade-off under realistic
> conditions.**

It was to deliver:

1. a sweep across multiple privacy budgets, **ε ∈ {1, 5, 10, 50}**,
2. a sweep across Byzantine fractions, **0 %, 10 %, 20 %, 30 %** (reported in
   *Research Objective 4*, which owns the attack grid),
3. a full ablation of each system component (reported in *Research Objective 1*),
4. measurement of **accuracy, F1, false-positive rate, convergence speed,
   ε-spend and compute overhead**.

This objective closes gap G4: the severity of the DP accuracy penalty was
uncharacterised for a 6G IDS, and the minimum usable ε was unknown.

The practical question behind it: **an operator is told "you must run at ε = 1" —
what does that cost them?** Without this curve there is no way to answer, and
privacy becomes a yes/no argument instead of a dial with a known price.

---

## 2. How to read the numbers

Every prediction falls into one of four buckets: **TP** (attack, correctly
flagged), **FP** (benign, wrongly flagged — a false alarm), **TN** (benign,
correctly left alone), **FN** (attack, missed).

| metric | formula | what it means in plain language |
|---|---|---|
| **Accuracy** | $\frac{TP+TN}{TP+TN+FP+FN}$ | of every flow, what fraction got the right label. Dominated by DDoS, which is 6.8 M of the 9.3 M test rows — never quote it alone |
| **Precision** | $\frac{TP}{TP+FP}$ | when it says "attack", how often is it right |
| **Recall** | $\frac{TP}{TP+FN}$ | of the attacks that really happened, how many it caught. **This is the per-family number in §4** |
| **F1** | $2\cdot\frac{P \cdot R}{P+R}$ | harmonic mean of the two — scores 0, not 0.5, for a model perfect on one and useless on the other |
| **Macro-F1** | $\frac{1}{34}\sum_c F_1^{(c)}$ | F1 averaged with **every one of the 34 classes counting equally**, so a 2,901-row family weighs as much as a 6.8 M-row one. The gap between this and accuracy *is* the class-imbalance problem |
| **FPR** | $\frac{FP}{FP+TN}$ | of all genuinely benign traffic, what fraction raised an alarm. Lower is better |

And the two privacy quantities:

- **ε (epsilon)** — the privacy budget. Formally, no single record can change
  the probability of any released model by more than a factor of $e^{\varepsilon}$.
  Smaller ε is a stronger guarantee. It is the dial this objective prices.
- **σ (sigma)** — the noise multiplier needed to achieve that ε. σ is what the
  accuracy actually pays for; ε is what it buys.

---

## 3. What was run

Four runs, identical in every respect except the privacy budget:

| run | target ε | achieved ε | noise σ |
|---|---|---|---|
| `pu_eps1` | 1 | 0.99 | 1.084 |
| `pu_eps5` | 5 | 5.00 | 0.597 |
| `pu_eps10` | 10 | 10.06 | 0.499 |
| `pu_eps50` | 50 | 49.98 | 0.342 |

FL + DP + Multi-Krum, no attackers, 10 gNBs, non-IID Dirichlet(α = 0.3), MLP,
DP-SGD (SGD momentum 0.9, lr 0.1), 30 rounds, δ = 1e-5, seed 42, CPU. ε is
accounted by Rényi differential privacy over a wide α grid and **calibrated for
the worst-case (smallest) client**, so the guarantee holds for every gNB. Every
run lands on its target within 1 %.

---

## 4. The result, figure by figure

Each measure gets its own chart, so nothing is squeezed. Six figures.

### Figure 1 — detection quality against the privacy budget

![Accuracy, macro-F1, macro-precision and macro-recall against the privacy budget](fig_privacy_utility.png)

| | |
|---|---|
| **x-axis** | the **privacy budget ε**, log scale, ticked at the four values actually run: 1, 5, 10, 50. Left = strong privacy, right = weak privacy. This is the dial a regulator or operator sets |
| **y-axis** | **"Score"** — every line here runs from 0 (useless) to 1 (perfect), so four different measures can honestly share one axis |
| **four lines** | four different ways of asking "how good is the detector", which disagree on purpose |

- **Accuracy** (blue, solid, circles) — $(TP+TN)/(TP+TN+FP+FN)$: of every flow in
  the test set, the fraction labelled correctly. The most intuitive line and the
  most flattering, because 6.8 M of the 9.3 M test rows are DDoS.
- **Macro-F1** (orange, solid, squares) — the F1 of each of the 34 classes,
  averaged with **every class weighted equally**. F1 is $2PR/(P+R)$, the harmonic
  mean of precision and recall, which scores 0 — not 0.5 — for a detector
  perfect at one and useless at the other. Because a 2,901-row family counts as
  much as a 6.8 M-row one, this is the honest line.
- **Macro-precision** (aqua, dashed, triangles) — averaged $TP/(TP+FP)$: when the
  detector says "attack", how often it is right.
- **Macro-recall** (violet, dashed, down-triangles) — averaged $TP/(TP+FN)$: of
  the attacks that really happened, how many it caught.

**What it shows:** all four rise left to right, so relaxing privacy buys
detection quality. Accuracy sits far above the other three at every budget —
that vertical gap is the class imbalance, not a privacy effect.

### Figure 2 — false alarms against the privacy budget

![False-positive rate against the privacy budget](fig_fpr_vs_epsilon.png)

| | |
|---|---|
| **x-axis** | the same privacy budget ε, log scale |
| **y-axis** | **false-positive rate**, $FP/(FP+TN)$ — of all genuinely benign traffic, the fraction that raised an alarm. **Lower is better here**, the opposite of Figure 1 |
| **one line** | red — there is only one benign class, so only one series |

**What it shows:** a deep V. The rate collapses from ε = 1 to ε = 5, then creeps
back up. This is the only non-monotonic curve in the objective, and it decides
the recommended operating point.

### Figure 3 — the noise each guarantee costs

![Noise multiplier sigma against the privacy budget](fig_sigma_vs_epsilon.png)

| | |
|---|---|
| **x-axis** | the same privacy budget ε, log scale |
| **y-axis** | **σ (sigma), the noise multiplier** — how much Gaussian noise is added to each gradient to achieve that ε. Not a score: this is the *mechanism* |
| **one line** | violet, labelled at each point |

**What it shows:** σ falls as ε rises. **This figure is the cause; Figures 1 and
2 are the effect.** ε is what a regulator specifies; σ is what the model actually
suffers.

| target ε | achieved ε | σ | accuracy | macro-F1 | macro-precision | macro-recall | FPR |
|---|---|---|---|---|---|---|---|
| 1 | 0.99 | 1.084 | 0.814 | 0.426 | 0.482 | 0.462 | 0.308 |
| **5** | 5.00 | 0.597 | **0.839** | 0.463 | 0.523 | 0.484 | **0.012** |
| 10 | 10.06 | 0.499 | 0.853 | 0.470 | 0.481 | 0.493 | 0.032 |
| 50 | 49.98 | 0.342 | 0.883 | 0.493 | 0.528 | 0.516 | 0.049 |
| *(no privacy)* | – | – | *0.893* | *0.594* | *0.651* | *0.600* | *0.022* |

### Figures 4 and 5 — how each budget converges

![Accuracy per round at each privacy budget](fig_eps_convergence_accuracy.png)

![Macro-F1 per round at each privacy budget](fig_eps_convergence_macro_f1.png)

| | |
|---|---|
| **x-axis** | the **communication round**, 1 to 30. One round = server sends the model → 10 gNBs train on their own data → updates come back → Multi-Krum aggregates them |
| **y-axis** | accuracy in Figure 4, macro-F1 in Figure 5, both evaluated on held-out data after each round |
| **four lines** | one per privacy budget |
| **the circle** | on Figure 4, the first round reaching 90 % of that run's own final accuracy — the convergence-speed number |

**What they show:** whether privacy changes how the model *gets* there or only
where it *ends up*.

### Figure 6 — detection by attack family

![Recall for each attack family, ordered by how many test rows it has](fig_per_category.png)

| | |
|---|---|
| **x-axis** | **recall**, 0 to 1 — of that family's traffic, the fraction the detector caught. The dashed line at 0.5 is a readability marker, not a threshold from the literature |
| **y-axis** | the eight attack families, **ordered by size** — largest at the top, smallest at the bottom |
| **the bars** | one per family, single colour because there is only one quantity. Each label gives the recall and how many held-out rows that family has |

Ordering by size rather than by score is deliberate: **the ordering is the
finding.**

| family | test rows | recall |
|---|---|---|
| DDoS | 6,796,915 | 0.961 |
| DoS | 1,618,148 | 0.825 |
| Mirai | 526,827 | 0.994 |
| Benign | 219,639 | 0.978 |
| MITM / Spoofing | 97,302 | 0.999 |
| Recon | 70,915 | 0.647 |
| Malware / Brute-force | 4,680 | 0.240 |
| Injection | 2,901 | **0.000** |

---

## 5. Analysis

### Accuracy — a clean, monotonic price list

Every relaxation of the budget buys utility, with no reversals: 0.814 → 0.839 →
0.853 → 0.883, approaching the 0.893 non-private ceiling. That monotonicity is
what makes ε a usable dial rather than a gamble — an operator handed a
regulatory constraint can read the cost off this table before deploying
anything.

**ε = 5 is the operating point to recommend.** It costs 5.3 accuracy points
against the non-private ceiling. Tightening all the way to ε = 1 costs only 2.5
points more than ε = 5 on accuracy, which sounds cheap — until you look at the
false-alarm column.

### Macro-F1 — the real cost of privacy, and it is not about privacy

0.426 → 0.493 across the sweep, against 0.594 without privacy. Macro-F1 tracks
accuracy in direction but sits 0.35–0.40 below it at *every* budget, including
the non-private row. **That gap is not a privacy effect** — noise does not create
it and removing noise does not close it. It is the 6000:1 class imbalance,
quantified in §4's per-family table.

The privacy-specific part of the macro-F1 story is the *rate* of the drop: from
0.594 to 0.463 at ε = 5, a 22 % relative fall against accuracy's 6 %. Rare
classes are always the first casualty of DP noise, because their gradient signal
is smallest relative to the noise added.

### Precision and recall — degradation is symmetric

Macro-precision moves 0.482 → 0.528 and macro-recall 0.462 → 0.516 across the
sweep, and the two stay within about 0.04 of each other at every budget. The
noise is blurring the decision boundary evenly rather than pushing the model
toward over- or under-flagging. This matters: a private model that quietly
*missed* attacks while keeping precision would be far more dangerous than one
that degrades symmetrically, and this one degrades symmetrically.

### False-positive rate — non-monotonic, and worth explaining before you are asked

0.308 → **0.012** → 0.032 → 0.049. It falls by a factor of 25 from ε = 1 to
ε = 5, then climbs slowly. Two competing effects:

- at ε = 1 the noise is heavy enough (σ = 1.084) that the model misreads benign
  traffic outright — 31 % of benign flows raise an alarm, which is unusable;
- as ε grows the model sharpens and becomes more willing to flag traffic, which
  raises both detection *and* false alarms.

The minimum sits at ε = 5, where the false-alarm rate is **lower than running
with no privacy at all** (0.012 against 0.022). This is the strongest practical
argument in the objective: at the recommended budget, privacy is not a tax on
the operator's experience — it improves it.

### σ — why privacy is affordable at this scale

The third panel shows σ falling 1.084 → 0.342 as the budget relaxes. What makes
these numbers small in the first place is **amplification by subsampling**: each
gNB holds millions of rows, so the Poisson sampling rate for any one batch is
tiny (q = 1.32 × 10⁻³), and a given (ε, δ) needs far less noise than it would on
a small shard. **More data does not only improve accuracy — it makes the same
privacy guarantee cheaper.**

### Convergence speed — one extra consideration at tight budgets

At ε ≥ 5 every run is within 10 % of its final accuracy by **round 2**. At
ε = 1 it takes **6 rounds**. Heavy noise does not stop the model converging, but
it does slow the early rounds — worth knowing if communication rounds are the
scarce resource.

### Per-family recall — the ordering is the finding

The six families with more than 70,000 test rows are all detected well, 0.647 to
0.999. The two that are missed are also the two smallest — Malware/Brute-force
at 0.240 and Injection at 0.000, together 7,581 rows, **0.08 % of the test set**.
There is simply not enough of them to learn from, and *more data makes this
worse, not better*, because the imbalance is a property of the corpus.

**Benign recall of 0.978 is the number an operator cares about most.** It is what
produces the low false-alarm rate: 97.8 % of benign traffic is correctly left
alone.

**Accuracy of 0.892 must never be quoted alone.** It is dominated by the DDoS
row. Macro-F1 belongs in the same sentence, every time, and the coarse
8-category view above is the more defensible operational granularity than the
34-class breakdown.

---

## 6. Files in this folder

| file | what it is |
|---|---|
| `fig_privacy_utility.png` | accuracy, macro-F1, precision and recall against ε |
| `fig_fpr_vs_epsilon.png` | false-alarm rate against ε |
| `fig_sigma_vs_epsilon.png` | the noise each budget requires |
| `fig_eps_convergence_accuracy.png` | accuracy per round, at each budget |
| `fig_eps_convergence_macro_f1.png` | macro-F1 per round, at each budget |
| `fig_per_category.png` | recall by attack family, with support |
| `pu_eps*.json` | the full result of each run — every per-round metric, its config, the final scores and the per-family breakdown |
| `pu_eps*_timeline.csv` | the same per-round metrics as a spreadsheet |

Regenerate the figures from the run files (trains nothing, takes seconds):

```bash
cd code && python scripts/make_figures.py results
```

Related: the attack-fraction sweep this objective also calls for is in
*Research Objective 4*; the component ablation is in *Research Objective 1*;
per-round compute cost is in `../fig_compute_overhead.png`.
