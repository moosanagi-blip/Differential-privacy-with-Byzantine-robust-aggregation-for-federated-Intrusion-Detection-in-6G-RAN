# DP-FL-IDS

Reference implementation for **"Composing differential privacy with
Byzantine-robust aggregation for federated intrusion detection in 6G radio
access networks."**

A federated intrusion detection framework for a simulated 10-gNB 6G O-RAN
slice. Each base station trains on traffic it never releases, every update is
made (ε, δ)-differentially private before it leaves the node, and the
aggregator filters malicious submissions with Multi-Krum before averaging.

This repository contains the framework, the experiment driver, and the saved
per-run results for the campaign reported in the paper. It does not contain
the dataset (see [Getting the data](#getting-the-data)).

---

## What the campaign found

Measured on the complete CICIoT2023 corpus, all 46,686,579 flows, across ten
non-IID shards and 30 training rounds. Every value is scored on the full
9,337,327-record held-out set.

| Configuration | Accuracy | Macro-F1 | False-alarm rate |
|---|---|---|---|
| Federated learning only | 0.892 | 0.575 | 0.019 |
| + differential privacy (ε=5) | 0.810 | 0.459 | 0.009 |
| + Multi-Krum | 0.893 | 0.590 | 0.022 |
| + both | 0.839 | 0.461 | 0.012 |

Under a persistent 30% sign-flip attack, Multi-Krum admitted **0 of 90**
poisoned updates with privacy enabled, exactly as it did with privacy
disabled. The margin between honest and malicious Krum distance scores
narrows from 70.7× to 38.2× under noise without closing.

Full analysis is in [`results/RESULTS.md`](results/RESULTS.md), with one
file per research question in `results/Research Objective */`.

---

## Layout

```
code/
  main.py                 narrated 17-step walkthrough of the whole pipeline
  run_experiment.py       the experiment driver (ablation, ε sweep, attacks…)
  requirements.txt
  src/
    data/                 CICIoT2023 loading, RAN feature synthesis, sharding
    models/               MLP, LSTM (Opacus DPLSTM), Transformer
    privacy/              DP-SGD engine, RDP accounting, ε schedules
    fl/                   round loop, aggregation rules, Flower engine
    attacks/              Byzantine client behaviours
    evaluation/           metrics, including the operational FPR definition
    analysis/             the DP × Multi-Krum interaction study
    utils/                plotting and reporting
  scripts/
    full_scale.py         the driver that produced the reported campaign
    make_figures.py       rebuilds every figure from saved results, in seconds
    multiseed.py          repeat the campaign across several seeds
    tune_adaptive_eps.py  wider sweep over noise schedules
    peek.py               inspect the prepared parquet shards
results/                  saved per-run JSON, timelines, figures, analysis
docs/threat_model.md      adversaries, trust assumptions, what is out of scope
data_full/                a 50-row sample of the prepared data, in real units
```

The code assumes `code/` sits one level below the repository root, because
paths resolve relative to that root (`code/src/data/config.py`). Keep the
layout as it is.

---

## Install

Python 3.10 or later.

```bash
cd code
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Pinned versions: torch 2.6.0, opacus 1.6.0, flwr 1.30.0, scikit-learn 1.7.2,
pandas 2.3.3, pyarrow 23.0.1. The reported campaign ran on CPU; a GPU is
optional and only helps the recurrent model.

---

## Run it

**See the whole pipeline explained, step by step.** This is the fastest way to
understand what the system does. It pauses between steps and prints what each
one does and why it matters.

```bash
cd code
python main.py                   # pauses between steps
python main.py --no-pause        # straight through
python main.py --replay          # narrate the saved results, train nothing
```

**Rebuild every figure from the saved results.** Takes seconds; touches
neither the dataset nor the model. This works straight after cloning, with no
data and no training.

```bash
cd code
python scripts/make_figures.py            # defaults to results/
```

Paths given to this script resolve against the repository root, not the
working directory, so pass `results` rather than `../results`.

**Reproduce the reported campaign.** All 27 runs, 30 rounds each. This needs
the prepared dataset (below) and roughly 14 hours of CPU time.

```bash
python scripts/full_scale.py --rounds 30 --byz-fracs 0 0.1 0.2 0.3
```

**Run one block on its own:**

```bash
python run_experiment.py --block ablation        # component contributions
python run_experiment.py --block privacy_utility # the ε sweep
python run_experiment.py --block byzantine       # attacks and defences
python run_experiment.py --block adaptive_eps    # noise schedules
python run_experiment.py --block interaction     # DP × Multi-Krum
```

---

## Getting the data

The corpus is **CICIoT2023**, published by the Canadian Institute for
Cybersecurity and available from
<https://www.unb.ca/cic/datasets/iotdataset-2023.html>. It is roughly 13 GB
of CSV across 169 parts and is not redistributed here.

Point the pipeline at your copy and build the shards:

```bash
export DPFLIDS_RAW_DIR=/path/to/CICIoT2023      # Windows: set DPFLIDS_RAW_DIR=E:\CICIoT2023
cd code
python -m src.data.build_scaled
```

Two streaming passes, about 15 minutes, peaking near 1.1 GB of RAM. The result
is ten client shards plus a held-out set under `data_full/`.

The seven radio-layer features are **synthetic**. No public dataset carries
both real 6G radio telemetry and labelled intrusions, so they are generated
from 3GPP-specified ranges and conditioned on the attack family
(`code/src/data/ran_augment.py`). The 46 network-flow features are real
measurements. This is a stated limitation of the work, not a hidden
assumption.

---

## Reproducibility notes

- Every reported run uses **seed 42**. Run-to-run variance was not estimated
  at full corpus scale. `scripts/multiseed.py` repeats the campaign across
  several seeds if you want error bars.
- The privacy budget is calibrated on the **smallest** client shard, so the
  stated ε holds for every participant. Calibrating on the average shard
  would report ε = 5.0 while the smallest client actually spends 10.7.
- Robust aggregators are given the **true** number of compromised clients.
  This is standard in the Krum literature and it is optimistic.
- Krum tolerates f attackers only while n ≥ 2f + 3, so with ten clients the
  guarantee expires above three. The 30% attack is at that boundary.
- Two engines produce identical results: a sequential simulator (used for the
  campaign) and a genuine Flower deployment path. Select with
  `--engine flower`.

---

## License

MIT. See [LICENSE](LICENSE).

The CICIoT2023 dataset is not covered by this license and is not
redistributed here; it remains under the terms set by the Canadian Institute
for Cybersecurity.

---

## Citation

```bibtex
@article{dpflids2026,
  title  = {Composing Differential Privacy with Byzantine-Robust Aggregation
            for Federated Intrusion Detection in 6G Radio Access Networks},
  author = {Musa and [Supervisor Name]},
  year   = {2026},
  note   = {Under review}
}
```
